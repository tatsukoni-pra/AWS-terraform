import base64
import hmac
import hashlib
from urllib import parse
from base64 import b64decode
import os

def verify_slack_request(event: dict, slack_signing_secret: str) -> bool:
    """
    Slackからのリクエストかどうかを検証する
    """
    timestamp = event["headers"]["x-slack-request-timestamp"]
    body = event["body"]
    if event["isBase64Encoded"]:
        body = base64.b64decode(body).decode("utf-8")

    sig_basestring = f"v0:{timestamp}:{body}".encode("utf-8")
    slack_signing_secret = bytes(slack_signing_secret, "utf-8")

    my_signature = "v0=" + hmac.new(
        slack_signing_secret, sig_basestring, hashlib.sha256
    ).hexdigest()

    result = hmac.compare_digest(my_signature, event["headers"]["x-slack-signature"])
    return result

def handler(event, context):
    body = b64decode(event.get("body")).decode()
    request_body = parse.parse_qs(body)

    if verify_slack_request(event, os.environ["SLACK_SIGNING_SECRET"]):
        print(request_body)
